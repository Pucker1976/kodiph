# -*- coding: utf-8 -*-
import sys
import urllib.parse


class AddonRouter:

    def __init__(self):
        self.routes = {}
        self.base_url     = sys.argv[0] if len(sys.argv) > 0 else ''
        self.addon_handle = int(sys.argv[1]) if len(sys.argv) > 1 else -1
        self.params_str   = sys.argv[2] if len(sys.argv) > 2 else ''

    def add_route(self, name, function):
        self.routes[name] = function

    def build_url(self, route_name, **kwargs):
        params = {'ruta': route_name}
        params.update(kwargs)
        return '{}?{}'.format(self.base_url, urllib.parse.urlencode(params))

    def parse_params(self):
        return dict(urllib.parse.parse_qsl(self.params_str.lstrip('?')))

    def handle(self):
        params = self.parse_params()
        route_name = params.get('ruta', 'menu')
        if route_name in self.routes:
            kwargs = {k: v for k, v in params.items() if k != 'ruta'}
            self.routes[route_name](**kwargs)
        elif 'menu' in self.routes:
            self.routes['menu']()


router = AddonRouter()
