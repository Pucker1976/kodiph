# -*- coding: utf-8 -*-
"""
__init__.py - Inicializacion del paquete

Este archivo vacio (o con poco contenido) le dice a Python que esta carpeta
es un paquete importable. Es necesario para poder hacer:
    from resources.lib.scraper import MiScraper
"""
