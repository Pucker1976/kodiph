# CHANGELOG — plugin.video.miaddon

## v1.2.0 — 2026-06-30

### Categorias dinamicas
- Las categorias se cargan ahora directamente desde `es.pornhub.com/categories` al iniciar el plugin.
- Se incluyen miniaturas reales de cada categoria obtenidas del sitio.
- Nuevo metodo `_scrape_categorias()` con soporte para links en formato `?c=ID` y rutas tipo `/amateur`.
- Tabla interna de conversion slug -> ID de categoria (`_SLUG_ID`) para manejar rutas que no incluyen el ID numerico.
- Fallback automatico al listado hardcodeado si el scraping falla (sin errores visibles para el usuario).

### Correcciones de URLs de categoria
- `base_url` vuelve a `https://es.pornhub.com` (el subdominio al que siempre redirige la geolocalizacion IP desde España).
- Eliminadas rutas tipo `/amateur`, `/lesbian`, etc. que retornan 404 en el subdominio ES.
- Categorias fijas (Mas vistos, Nuevos, Top valorados) siempre presentes con formato `?o=mv/n/tr`.
- Categorias por ID con formato `?c=ID&o=mv`: Amateur (36), Anal (2), Lesbiana (6), MILF (8), Teen (18), Latina (21), Espanol (62), POV (226), Threesome (176), Creampie (117).

---

## v1.1.0 — 2026-06-30

### Correccion HTTP 410 en reproduccion HLS
- `reproducir_video` ahora envia tanto `manifest_headers` como `stream_headers` a `inputstream.adaptive`.
- Headers incluyen User-Agent, Referer (URL real del video) y Cookie de sesion codificados con `urllib.parse.quote`.
- Fix: el Referer apunta a la pagina del video, no a la homepage, para satisfacer la firma HMAC del CDN.
- `get_url_video` retorna tupla `(url, cookies_str)` en lugar de solo la URL.

### Correcciones de dominio y cookies
- `base_url` cambiado a `https://www.pornhub.com` (primera iteracion, revertida en v1.2).
- Dominio de cookies cambiado de `es.pornhub.com` a `pornhub.com` para aplicar a todos los subdominios.
- Añadida cookie `pref_language=es` en dominio `pornhub.com`.

### Diagnostico mejorado
- `get_peliculas` loguea el selector CSS que encuentra items, el HTML de inicio de pagina y el total de resultados.
- `get_url_video` loguea cada intento de extraccion de URL (flashvars, videoUrl, regex directo).
- Multiples selectores CSS probados en orden para mayor compatibilidad entre versiones del sitio.

---

## v1.0.0 — version inicial

- Estructura base del addon: `main.py`, `router.py`, `scraper.py`.
- Menu principal con categorias hardcodeadas.
- Scraping de listado de videos con BeautifulSoup.
- Extraccion de URL de video desde `flashvars_XXXX` y patrones `videoUrl` en el HTML.
- Soporte de `inputstream.adaptive` para streams HLS (.m3u8) y MP4.
- `cloudscraper` bundleado para bypass de Cloudflare.
- Cookies de sesion: `age_verified=1`, `platform=pc`.
