# -*- coding: utf-8 -*-
import sys
import os
import urllib.parse
import xbmcplugin
import xbmcgui

addon_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(addon_dir, 'resources', 'lib'))

from router import router


def crear_listitem(titulo, url, imagen='', es_folder=True, info=None):
    listitem = xbmcgui.ListItem(label=titulo)
    if info:
        listitem.setInfo('video', {
            'title':    info.get('title', titulo),
            'plot':     info.get('plot', ''),
            'year':     info.get('year', 0),
            'genre':    info.get('genre', ''),
            'rating':   info.get('rating', 0),
            'duration': info.get('duration', 0),
        })
    if imagen:
        listitem.setArt({'thumb': imagen, 'poster': imagen, 'fanart': imagen})
    if not es_folder:
        listitem.setProperty('IsPlayable', 'true')
    return (url, listitem, es_folder)


def mostrar_menu_principal():
    from scraper import MiScraper
    scraper = MiScraper()
    categorias = scraper.get_categorias()

    items = []
    for cat in categorias:
        url = router.build_url('listar_peliculas', categoria_url=cat['url'])
        items.append(crear_listitem(
            titulo=cat['nombre'],
            url=url,
            imagen=cat.get('imagen', ''),
            es_folder=True
        ))

    addon_handle = int(sys.argv[1])
    xbmcplugin.addDirectoryItems(addon_handle, items, len(items))
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)


def listar_peliculas(categoria_url):
    from scraper import MiScraper
    scraper = MiScraper()
    peliculas = scraper.get_peliculas(categoria_url)

    items = []
    for peli in peliculas:
        url = router.build_url('reproducir', video_url=peli['url'])
        items.append(crear_listitem(
            titulo=peli['titulo'],
            url=url,
            imagen=peli.get('imagen', ''),
            es_folder=False,
            info={
                'title':    peli['titulo'],
                'plot':     peli.get('sinopsis', ''),
                'year':     peli.get('anio', 0),
                'genre':    peli.get('genero', ''),
                'rating':   peli.get('puntuacion', 0),
                'duration': peli.get('duracion', 0),
            }
        ))

    addon_handle = int(sys.argv[1])

    if not items:
        xbmcgui.Dialog().notification(
            'Sin resultados',
            'No se encontraron videos. El sitio puede estar bloqueando la peticion.',
            xbmcgui.NOTIFICATION_WARNING,
            5000
        )

    xbmcplugin.addDirectoryItems(addon_handle, items, len(items))
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)


_UA = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/125.0.0.0 Safari/537.36'
)


def reproducir_video(video_url):
    from scraper import MiScraper
    scraper = MiScraper()
    url_directa, cookies_str = scraper.get_url_video(video_url)

    addon_handle = int(sys.argv[1])
    if url_directa:
        listitem = xbmcgui.ListItem(path=url_directa)
        if '.m3u8' in url_directa:
            listitem.setProperty('inputstream', 'inputstream.adaptive')
            listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
            listitem.setMimeType('application/x-mpegURL')
            listitem.setContentLookup(False)
            headers = 'User-Agent={}&Referer={}'.format(
                urllib.parse.quote(_UA),
                urllib.parse.quote(video_url)
            )
            if cookies_str:
                headers += '&Cookie={}'.format(urllib.parse.quote(cookies_str))
            listitem.setProperty('inputstream.adaptive.manifest_headers', headers)
            listitem.setProperty('inputstream.adaptive.stream_headers', headers)
        elif '.mp4' in url_directa:
            listitem.setMimeType('video/mp4')
            listitem.setContentLookup(False)
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem)
    else:
        xbmcgui.Dialog().notification(
            'Error',
            'No se pudo obtener el enlace del video.',
            xbmcgui.NOTIFICATION_ERROR,
            5000
        )
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())


if __name__ == '__main__':
    router.add_route('menu', mostrar_menu_principal)
    router.add_route('listar_peliculas', listar_peliculas)
    router.add_route('reproducir', reproducir_video)
    router.handle()
