# -*- coding: utf-8 -*-
import re
import json
import os
import sys
import xbmc

_LIB_DIR = os.path.dirname(os.path.abspath(__file__))
if _LIB_DIR not in sys.path:
    sys.path.insert(0, _LIB_DIR)

try:
    import requests
    from bs4 import BeautifulSoup
except ImportError:
    addon_dir = os.path.dirname(os.path.dirname(_LIB_DIR))
    sys.path.insert(0, os.path.join(addon_dir, '..', 'script.module.requests', 'lib'))
    sys.path.insert(0, os.path.join(addon_dir, '..', 'script.module.beautifulsoup4', 'lib'))
    import requests
    from bs4 import BeautifulSoup

try:
    import cloudscraper
    _CLOUDSCRAPER_DISPONIBLE = True
except ImportError:
    _CLOUDSCRAPER_DISPONIBLE = False


class MiScraper:

    def __init__(self):
        self.base_url = 'https://es.pornhub.com'

        self.headers = {
            'User-Agent': (
                'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                'AppleWebKit/537.36 (KHTML, like Gecko) '
                'Chrome/125.0.0.0 Safari/537.36'
            ),
            'Accept': (
                'text/html,application/xhtml+xml,application/xml;'
                'q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8'
            ),
            'Accept-Language': 'es-ES,es;q=0.9,en;q=0.8',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
        }

        if _CLOUDSCRAPER_DISPONIBLE:
            xbmc.log('[miaddon] cloudscraper DISPONIBLE', xbmc.LOGWARNING)
            self.session = cloudscraper.create_scraper(
                browser={'browser': 'chrome', 'platform': 'windows', 'mobile': False}
            )
        else:
            xbmc.log('[miaddon] cloudscraper NO disponible, usando requests estandar', xbmc.LOGWARNING)
            self.session = requests.Session()

        self.session.headers.update(self.headers)
        self.session.cookies.set('age_verified', '1', domain='pornhub.com')
        self.session.cookies.set('platform', 'pc', domain='pornhub.com')
        self.session.cookies.set('pref_language', 'es', domain='pornhub.com')

        self._init_session()

    def _init_session(self):
        """Visita la homepage para establecer cookies de sesion validas."""
        try:
            r = self.session.get(self.base_url + '/', timeout=20)
            html = r.content.decode('utf-8', errors='ignore').replace('\x00', '')
            xbmc.log('[miaddon] Homepage: HTTP {} -> {}'.format(r.status_code, r.url), xbmc.LOGWARNING)
            xbmc.log('[miaddon] Homepage HTML inicio: {}'.format(html[:200].replace('\n', ' ')), xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log('[miaddon] Homepage error: {}'.format(e), xbmc.LOGWARNING)

    # Mapeo slug→ID de categoría para cuando la página usa rutas tipo /amateur
    _SLUG_ID = {
        'amateur': 36, 'anal': 2, 'asian': 3, 'big-dick': 4, 'big-tits': 5,
        'lesbian': 6, 'big-ass': 7, 'milf': 8, 'brunette': 9, 'blonde': 10,
        'blowjob': 11, 'college': 12, 'masturbation': 13, 'ebony': 15,
        'hardcore': 16, 'interracial': 17, 'teen': 18, 'bbw': 20,
        'latina': 21, 'mature': 22, 'red-head': 23, 'small-tits': 24,
        'cumshot': 25, 'gangbang': 26, 'vintage': 30, 'babe': 31,
        'double-penetration': 34, 'casting': 53, 'public': 60,
        'spanish': 62, 'role-play': 74, 'fetish': 100, 'creampie': 117,
        'threesome': 176, 'squirt': 250, 'pov': 226, 'hentai': 1,
        'verified-amateurs': 261, 'orgy': 25,
    }

    def get_categorias(self):
        v = self.base_url + '/video'
        fijas = [
            {'nombre': 'Mas vistos',    'url': v + '?o=mv', 'imagen': ''},
            {'nombre': 'Nuevos',        'url': v + '?o=n',  'imagen': ''},
            {'nombre': 'Top valorados', 'url': v + '?o=tr', 'imagen': ''},
        ]
        dinamicas = self._scrape_categorias()
        if dinamicas:
            return fijas + dinamicas
        return fijas + [
            {'nombre': 'Amateur',   'url': v + '?c=36&o=mv',  'imagen': ''},
            {'nombre': 'Anal',      'url': v + '?c=2&o=mv',   'imagen': ''},
            {'nombre': 'Lesbiana',  'url': v + '?c=6&o=mv',   'imagen': ''},
            {'nombre': 'MILF',      'url': v + '?c=8&o=mv',   'imagen': ''},
            {'nombre': 'Teen (18+)','url': v + '?c=18&o=mv',  'imagen': ''},
            {'nombre': 'Latina',    'url': v + '?c=21&o=mv',  'imagen': ''},
            {'nombre': 'Espanol',   'url': v + '?c=62&o=mv',  'imagen': ''},
            {'nombre': 'POV',       'url': v + '?c=226&o=mv', 'imagen': ''},
            {'nombre': 'Threesome', 'url': v + '?c=176&o=mv', 'imagen': ''},
            {'nombre': 'Creampie',  'url': v + '?c=117&o=mv', 'imagen': ''},
        ]

    def _scrape_categorias(self):
        try:
            response = self.session.get(self.base_url + '/categories', timeout=20)
            xbmc.log('[miaddon] /categories HTTP {} -> {}'.format(
                response.status_code, response.url), xbmc.LOGWARNING)
            if response.status_code != 200:
                return []

            html = response.content.decode('utf-8', errors='ignore').replace('\x00', '')
            soup = BeautifulSoup(html, 'html.parser')

            items = []
            for sel in ['li.categoriesWrap', 'div.categoriesWrap',
                        'li[class*="categor"]', 'div[class*="categor"]']:
                found = soup.select(sel)
                if found:
                    xbmc.log('[miaddon] Selector categorias "{}": {} items'.format(
                        sel, len(found)), xbmc.LOGWARNING)
                    items = found
                    break

            if not items:
                xbmc.log('[miaddon] /categories: no items, HTML inicio: {}'.format(
                    html[:300].replace('\n', ' ')), xbmc.LOGWARNING)
                return []

            # Log primer item para referencia de estructura
            xbmc.log('[miaddon] Primer cat HTML: {}'.format(
                str(items[0])[:300].replace('\n', ' ')), xbmc.LOGWARNING)

            categorias = []
            for item in items:
                enlace = item.select_one('a[href]')
                if not enlace:
                    continue
                href = enlace.get('href', '').strip()

                nombre_elem = (item.select_one('.category_title') or
                               item.select_one('span.title') or
                               item.select_one('[class*="title"]') or
                               item.select_one('h5') or item.select_one('h4'))
                nombre = (nombre_elem.get_text(strip=True) if nombre_elem
                          else enlace.get('title', ''))
                if not nombre:
                    continue

                img = item.find('img')
                imagen = ''
                if img:
                    imagen = (img.get('data-thumb_url') or img.get('data-src') or
                              img.get('src') or '')

                cat_url = self._href_a_url_categoria(href)
                if cat_url:
                    categorias.append({'nombre': nombre, 'url': cat_url, 'imagen': imagen})

            xbmc.log('[miaddon] Total categorias dinamicas: {}'.format(len(categorias)),
                     xbmc.LOGWARNING)
            return categorias
        except Exception as e:
            xbmc.log('[miaddon] Error _scrape_categorias: {}'.format(e), xbmc.LOGWARNING)
            return []

    def _href_a_url_categoria(self, href):
        if not href or href == '#':
            return ''
        # Ya tiene ?c=ID — funciona directamente en es subdomain
        if '?c=' in href:
            url = self._completar_url(href)
            return url if '&o=' in url else url + '&o=mv'
        # /video?... sin ?c=
        if href.startswith('/video'):
            url = self.base_url + href
            return url if '&o=' in url else url + '&o=mv'
        # Ruta tipo /amateur — convertir mediante slug→ID
        if href.startswith('/'):
            slug = href.lstrip('/')
            cat_id = self._SLUG_ID.get(slug)
            if cat_id:
                return '{}/video?c={}&o=mv'.format(self.base_url, cat_id)
            # Sin ID conocido, intentar la ruta directa (puede fallar en es subdomain)
            return self.base_url + href
        return ''

    def get_peliculas(self, categoria_url):
        peliculas = []
        try:
            self.session.headers.update({'Referer': self.base_url + '/'})
            response = self.session.get(categoria_url, timeout=20)

            xbmc.log('[miaddon] HTTP {} para {}'.format(response.status_code, categoria_url), xbmc.LOGWARNING)
            xbmc.log('[miaddon] URL final: {}'.format(response.url), xbmc.LOGWARNING)
            html_text = response.content.decode('utf-8', errors='ignore').replace('\x00', '')
            html_inicio = html_text[:800].replace('\n', ' ') if html_text else '(VACIO)'
            xbmc.log('[miaddon] HTML inicio: {}'.format(html_inicio), xbmc.LOGWARNING)

            if response.status_code != 200:
                xbmc.log('[miaddon] Respuesta no-200, abortando', xbmc.LOGWARNING)
                return peliculas

            soup = BeautifulSoup(html_text, 'html.parser')

            selectores = [
                'li.pcVideoListItem',
                'li.videoBox',
                'div.pcVideoListItem',
                'li[class*="VideoListItem"]',
                'li[class*="videoBox"]',
                'div[class*="VideoListItem"]',
                'article.pcVideoListItem',
            ]

            items = []
            for sel in selectores:
                encontrados = soup.select(sel)
                xbmc.log('[miaddon] Selector "{}" -> {} resultados'.format(sel, len(encontrados)), xbmc.LOGWARNING)
                if encontrados:
                    items = encontrados
                    break

            if not items:
                # Log de todos los <li> y <div> con clase para diagnostico
                todos_li = soup.find_all('li', class_=True)[:5]
                for el in todos_li:
                    xbmc.log('[miaddon] li clase: {}'.format(el.get('class')), xbmc.LOGWARNING)
                todos_div = soup.find_all('div', class_=True)[:5]
                for el in todos_div:
                    xbmc.log('[miaddon] div clase: {}'.format(el.get('class')), xbmc.LOGWARNING)

            for item in items:
                enlace = (item.select_one('a[href*="viewkey"]') or
                          item.select_one('a[href*="view_video"]'))
                if not enlace:
                    continue
                href = enlace.get('href', '')

                titulo_elem = (item.select_one('span.title a') or
                               item.select_one('.title a') or
                               item.select_one('.title') or
                               item.select_one('a[title]'))
                if titulo_elem:
                    titulo = titulo_elem.get('title') or titulo_elem.get_text(strip=True)
                else:
                    titulo = enlace.get('title', 'Sin titulo')

                img = item.find('img')
                imagen = ''
                if img:
                    imagen = (img.get('data-thumb') or img.get('data-mediumthumb') or
                              img.get('data-src') or img.get('src') or '')

                duracion_elem = (item.select_one('var.duration') or
                                 item.select_one('.videoDuration'))
                duracion = self._parsear_duracion(
                    duracion_elem.get_text(strip=True) if duracion_elem else ''
                )

                if titulo and href:
                    peliculas.append({
                        'titulo':    titulo,
                        'url':       self._completar_url(href),
                        'imagen':    imagen,
                        'sinopsis':  '',
                        'anio':      0,
                        'genero':    '',
                        'puntuacion': 0,
                        'duracion':  duracion,
                    })

        except Exception as e:
            xbmc.log('[miaddon] Excepcion en get_peliculas: {}'.format(e), xbmc.LOGWARNING)

        xbmc.log('[miaddon] Total peliculas encontradas: {}'.format(len(peliculas)), xbmc.LOGWARNING)
        return peliculas

    def get_cookies_str(self):
        return '; '.join('{}={}'.format(c.name, c.value) for c in self.session.cookies)

    def get_url_video(self, video_url):
        """Retorna (url, cookies_str) o (None, '')."""
        try:
            self.session.headers.update({'Referer': self.base_url + '/'})
            response = self.session.get(video_url, timeout=20)
            xbmc.log('[miaddon] Video page HTTP {}: {}'.format(response.status_code, video_url), xbmc.LOGWARNING)
            html = response.content.decode('utf-8', errors='ignore').replace('\x00', '')
            cookies_str = self.get_cookies_str()

            # Intento 1: objeto flashvars_XXXX con mediaDefinitions
            match = re.search(r'var\s+flashvars_\d+\s*=\s*(\{.+?\})\s*;', html, re.DOTALL)
            xbmc.log('[miaddon] flashvars match: {}'.format(bool(match)), xbmc.LOGWARNING)
            if match:
                try:
                    data = json.loads(match.group(1))
                    mejor_url = None
                    for d in data.get('mediaDefinitions', []):
                        url = d.get('videoUrl', '')
                        if url and ('.mp4' in url or '.m3u8' in url):
                            mejor_url = url
                    if mejor_url:
                        url_final = mejor_url.replace('\\/', '/')
                        xbmc.log('[miaddon] URL desde flashvars: {}...'.format(url_final[:80]), xbmc.LOGWARNING)
                        return url_final, cookies_str
                except Exception as ex:
                    xbmc.log('[miaddon] Error parseando flashvars: {}'.format(ex), xbmc.LOGWARNING)

            # Intento 2: "videoUrl":"..." en el HTML
            for url in reversed(re.findall(r'"videoUrl"\s*:\s*"([^"]+)"', html)):
                url = url.replace('\\/', '/')
                if '.mp4' in url or '.m3u8' in url:
                    xbmc.log('[miaddon] URL desde videoUrl: {}...'.format(url[:80]), xbmc.LOGWARNING)
                    return url, cookies_str

            # Intento 3: URL directa con extension de video
            match = re.search(r'(https?://[^\s"\'<>]+?\.(?:mp4|m3u8))[\s"\'<>]', html)
            if match:
                xbmc.log('[miaddon] URL directa: {}...'.format(match.group(1)[:80]), xbmc.LOGWARNING)
                return match.group(1), cookies_str

            xbmc.log('[miaddon] No se encontro URL de video', xbmc.LOGWARNING)
            xbmc.log('[miaddon] HTML video inicio: {}'.format(html[:600].replace('\n', ' ')), xbmc.LOGWARNING)

        except Exception as e:
            xbmc.log('[miaddon] Error en get_url_video: {}'.format(e), xbmc.LOGWARNING)

        return None, ''

    def _parsear_duracion(self, texto):
        try:
            partes = texto.strip().split(':')
            if len(partes) == 2:
                return int(partes[0]) * 60 + int(partes[1])
            if len(partes) == 3:
                return int(partes[0]) * 3600 + int(partes[1]) * 60 + int(partes[2])
        except Exception:
            pass
        return 0

    def _completar_url(self, url):
        if not url:
            return ''
        if url.startswith('http'):
            return url
        if url.startswith('//'):
            return 'https:' + url
        if url.startswith('/'):
            return self.base_url + url
        return self.base_url + '/' + url
