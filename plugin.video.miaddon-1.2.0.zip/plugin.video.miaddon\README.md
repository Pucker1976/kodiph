# Mi Addon de Peliculas — plugin.video.miaddon

Addon de video para Kodi 21 (Omega) con scraping web y bypass de Cloudflare.

**Version actual:** 1.2.0

---

## Requisitos

- Kodi 21 (Omega) o superior
- Addon `inputstream.adaptive` instalado y habilitado
- Addons de modulos: `script.module.requests`, `script.module.beautifulsoup4`, `script.module.urllib3`

## Instalacion

1. Copia la carpeta `plugin.video.miaddon` en:
   `C:\Users\<usuario>\AppData\Roaming\Kodi\addons\`
2. Reinicia Kodi o ve a **Addons > Actualizar repositorios**.
3. El addon aparecera en **Mis Addons > Addons de video**.

## Estructura de archivos

```
plugin.video.miaddon/
├── addon.xml               — Metadatos del addon
├── main.py                 — Punto de entrada; menu, listado y reproduccion
├── CHANGELOG.md            — Historial de cambios
├── README.md               — Este archivo
└── resources/
    ├── settings.xml
    └── lib/
        ├── router.py       — Router de rutas del plugin
        ├── scraper.py      — Scraping de categorias, videos y URLs de reproduccion
        ├── cloudscraper/   — Libreria bundleada para bypass de Cloudflare
        ├── pyparsing/      — Dependencia de cloudscraper
        └── requests_toolbelt/  — Dependencia de cloudscraper
```

## Como funciona

### Categorias
Al abrir el addon se cargan dinamicamente las categorias desde el sitio. Las tres primeras (Mas vistos, Nuevos, Top valorados) son siempre fijas. El resto se obtiene en tiempo real con sus miniaturas y nombres actualizados.

### Reproduccion de video
Los videos usan `inputstream.adaptive` para streams HLS (`.m3u8`). Se envian al reproductor los headers necesarios (User-Agent, Referer y Cookie de sesion) para evitar errores HTTP 403/410 del CDN.

### Bypass de Cloudflare
Se usa `cloudscraper` bundleado para establecer la sesion inicial antes de hacer peticiones de scraping.

## Notas tecnicas

- El sitio redirige automaticamente las IPs de España a `es.pornhub.com`. Las URLs de categoria usan el formato `?c=ID&o=mv` que funciona en ese subdominio.
- Las URLs de tipo `/amateur`, `/lesbian`, etc. retornan 404 en el subdominio ES por lo que no se usan.
- El CDN firma las URLs HLS con HMAC; el Referer debe apuntar a la pagina del video (no a la homepage) para que la firma sea valida.

## Historial de versiones

Ver `CHANGELOG.md` para el detalle completo de cambios por version.
